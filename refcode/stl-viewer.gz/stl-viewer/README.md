stl-viewer
==========

OpenGL code to view STL geometry files

There are currently four (4) command-line arguments to run the code:

./showSTL.x [stl file name] [rotation x] [rotation y] [rotation z] 
