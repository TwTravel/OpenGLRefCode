/*---------------------------------------*
 *                                       *
 *          C A R T G E N + +            *
 *                                       *
 *   Copyright © 2012 Abhijit S. Joshi   *
 *   All Rights Reserved                 *
 *---------------------------------------*/

#ifndef READBINARY_H
#define READBINARY_H

// include files

#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <cmath>

#include "structs_and_classes.h"

#endif
