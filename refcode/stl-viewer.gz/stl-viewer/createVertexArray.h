#ifndef CREATE_VERTEX_ARRAY
#define CREATE_VERTEX_ARRAY
#include <iostream>
#include <vector>
#include <cmath>
#include "structs_and_classes.h"
#endif
