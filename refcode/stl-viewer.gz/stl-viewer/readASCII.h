#ifndef READASCII_H
#define READASCII_H

// include files

#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <cmath>

#include "structs_and_classes.h"

#endif
