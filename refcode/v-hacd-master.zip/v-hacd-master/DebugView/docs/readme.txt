Contains some documentation about how to use the NvRenderDebug remote debug visualization interface.
