^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package convex_decomposition
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.10 (2015-01-06)
-------------------
* Added tag 0.1.9 for changeset c7c2984fc16f
* Contributors: Dirk Thomas
