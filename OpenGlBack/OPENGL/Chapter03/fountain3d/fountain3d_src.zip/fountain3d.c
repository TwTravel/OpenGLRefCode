/*==========================================================================*/
/*  OpenGL Fountain 3D Demo (Particles)                                     */
/*  Author: Roman Podobedov                                                 */
/*  Email: romka@ut.ee                                                      */
/*  WEB: http://romka.demonews.com                                          */
/*  Date: 10 September 2000                                                 */
/*  Update: 30 September 2000                                               */
/*==========================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <GL/glut.h>
#include "texture.h"

#define PI 3.14159

struct particle
{
  float t;       /* Life time */
  float v;       /* Speed */
  float d;       /* Particle direction */
  float x, y, z; /* Particle Coordinates */
  float xd, zd;  /* X and Z increase values */
  char type;     /* type (moving or fading) */
  float a;       /* Fade alpha */
  struct particle *next, *prev;
};
struct point
{
  float x, y, z;
};

int WindW, WindH;
unsigned *teximage;    /* Particle texture */
GLuint texture[2];     /* Textures */
float a=0;
struct particle *fn[3];   /* Fountains */
char temp[128]="FPS: 0.000000";
/* For FPS */
int frame_counter=0;
time_t curtime;
clock_t last_time;
float cur_time;
float total_frames;
struct point upv, cam;        /* Camera UP vector, camera position */

/*=================== Initialization =======================================*/
void Init()
{
  fn[0] = NULL;
  fn[1] = NULL;
  fn[2] = NULL;
  upv.x = -5;
  upv.y = 5;
  upv.z = -5;
  cam.x = 200;
  cam.y = 200;
  cam.z = 200;
  glGenTextures(3, texture); 
  glClearColor(0, 0, 0, 0);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE);
  glEnable(GL_BLEND);
  glEnable(GL_TEXTURE_2D);
}

/* Draw string on screen */
void draw_string(void *font, const char* string) 
{
  while(*string)
    glutStrokeCharacter(font, *string++);
}

static float gettime(void)
{
  clock_t time_new, time_raz;

  time_new=clock();
  time_raz=time_new-last_time;
  last_time=time_new;

  return(time_raz/(float)CLOCKS_PER_SEC);
}

/*=================== Load Texture =========================================*/
void LoadTexture(char *fn, int t_num)
{
  int texwid, texht;
  int texcomps;
 
  teximage = read_texture(fn, &texwid, &texht, &texcomps);
  if (!teximage)
  {
    printf("Sorry, can't read texture file...");
    exit(0);
  }
  glBindTexture(GL_TEXTURE_2D, texture[t_num]);
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, texwid, texht, 0, GL_RGBA, GL_UNSIGNED_BYTE, teximage);

  glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST); 
  glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST); 

  if ((t_num == 0) || (t_num == 2)) glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE); /* Special for particles */
  if (t_num == 1)
  {
    /* Repeat texture parameters for ground */
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); 
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT); 
  }
  free(teximage);
} 

void Reshape(int width, int height)
{
  glViewport(0, 0, width, height);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(-0.5, 0.5, -0.5, 0.5, 1, 1000);
  glMatrixMode(GL_MODELVIEW);
  
  WindW = width;
  WindH = height;
}

/*=================== Add new particles ====================================*/
void AddParticles()
{
  struct particle *tempp;
  int i, j;
  
  for (j=0; j<3; j++)
    for (i=0; i<2; i++)
    {
      tempp = (struct particle *)malloc(sizeof(struct particle));
      if (fn[j]) fn[j]->prev = tempp;
      tempp->next = fn[j];
      fn[j] = tempp;
  
      tempp->t = -9.9;
      tempp->v = (float)(rand() % 200000)/100000+1; /* Speed */
      tempp->d = (float)(rand() % 400)/100-2;     /* Direction angle: -2..2 */
      /* Start coordinates */
      tempp->x = 0;
      tempp->y = 0;
      tempp->z = 0;
      tempp->xd = cos((tempp->d*3.14159)/180)*tempp->v/4;
      tempp->zd = sin((tempp->d*3.14159)/180)*tempp->v;
      tempp->type = 0; /* Moving particle */
      tempp->a = 1; /* Alpha is 1 */
    }
}

/*=================== Move particles routine ================================*/
void MoveParticles()
{
  struct particle *tempp;
  int j;

  for (j=0; j<3; j++)
  {
    tempp = fn[j]; /* Select fountain */
    while (tempp)
    {
      if (tempp->type == 0) /* If particle on the fly */
      {
        tempp->x += tempp->xd;
        tempp->z += tempp->zd;
        tempp->y = -(9.8*(tempp->t*tempp->t/4))/2+122.5; /* H = gt^2/2 (height of current particle) */
        tempp->t += 0.1; /* Increase life time */
        if (tempp->y < 0) tempp->type = 1; /* If particle on the ground */
      }
      else /* Particle on the ground */
      {
        tempp->y = -(9.8*(tempp->t*tempp->t/4))/2+122.5; /* H = gt^2/2 */
        tempp->a -= 0.1; /* Fade particle */
      }
      tempp = tempp->next; /* Next particle in the list */
    }
  }
}

/*=================== Delete particles routine ==============================*/
void DeleteParticles()
{
  struct particle *tempp, *temp1;
  int j;

  for (j=0; j<3; j++)
  {
    tempp = fn[j];
    while (tempp)
    {
      if ((tempp->type == 1) && (tempp->a <= 0)) /* Particle is dead */
      {
        /* Delete this particle */
        temp1 = tempp->prev;
        tempp->prev->next = tempp->next;
        if (tempp->next) tempp->next->prev = temp1;
        free(tempp);
        tempp = temp1;
      }
      tempp = tempp->next;
    }
  }
}

/*=================== C = A x B  (Vector multiply) ==========================*/
void vect_mult(struct point *A, struct point *B, struct point *C)
{
  /* Vector multiply */
  C->x = A->y*B->z - A->z*B->y;
  C->y = A->z*B->x - A->x*B->z;
  C->z = A->x*B->y - A->y*B->x;
}

/*=================== Vector normalization ==================================*/
void normalize(struct point *V)
{
  float d;

  /* Vector length */
  d = sqrt(V->x*V->x + V->y*V->y + V->z*V->z);

  /* Normalization */
  V->x /= d; 
  V->y /= d; 
  V->z /= d; 
}

void DrawFountain()
{
  int j;
  struct particle *tempp;
  struct point vectd, vectl; /* Direction vector and vector left */
  float alpha, ttx, ttz;

  glBindTexture(GL_TEXTURE_2D, texture[0]);

  AddParticles();
  MoveParticles();
  DeleteParticles();
  
  glPushMatrix();
  for (j=0; j<3; j++)
  {
    glBegin(GL_QUADS);
    tempp = fn[j];
    while (tempp)
    {
      /* Rotate fountains */
      alpha = ((j*120+a)*PI)/180;
      ttx = tempp->x*cos(alpha)-tempp->z*sin(alpha);
      ttz = tempp->x*sin(alpha)+tempp->z*cos(alpha);
      /* Calculate direction vector (A) */
      vectd.x = ttx - cam.x;
      vectd.y = tempp->y - cam.y;
      vectd.z = ttz - cam.z;
      /* Calculate vector left (C = UPxA) */
      vect_mult(&vectd, &upv, &vectl);
      normalize(&vectl);
      vectl.x *= 5;
      vectl.y *= 5;
      vectl.z *= 5;
      glColor4f(0.5, 0.5, 1, tempp->a);
      /* Draw polygon and particle texture mapping */
      glTexCoord2f(0, 0); glVertex3f((ttx-vectl.x), (tempp->y-upv.y), (ttz-vectl.z));
      glTexCoord2f(1, 0); glVertex3f((ttx+vectl.x), (tempp->y-upv.y), (ttz+vectl.z));
      glTexCoord2f(1, 1); glVertex3f((ttx+vectl.x), (tempp->y+upv.y), (ttz+vectl.z));
      glTexCoord2f(0, 1); glVertex3f((ttx-vectl.x), (tempp->y+upv.y), (ttz-vectl.z));
      tempp = tempp->next; /* Next particle in the list */
    }
    glEnd();
  }
  glPopMatrix();
}

/*=================== Drawing function =====================================*/
void Draw(void)
{
  glClear(GL_COLOR_BUFFER_BIT);
  
  glLoadIdentity();
  glBindTexture(GL_TEXTURE_2D, texture[1]);
  a += 0.2;
  gluLookAt(cam.x, cam.y, cam.z, 0, 0, 0, upv.x, upv.y, upv.z); /* Set camera position and target point */
  
  /* Draw ground */
  glColor3f(0.9, 0.9, 1);
  glPushMatrix();
  glRotatef(a, 0, -1, 0);
  glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(-100, 0, -100);
    glTexCoord2f(2, 0); glVertex3f(-100, 0, 100);
    glTexCoord2f(2, 2); glVertex3f(100, 0, 100);
    glTexCoord2f(0, 2); glVertex3f(100, 0, -100);
  glEnd();
  glPopMatrix();

  /* Draw fountain */
  DrawFountain();

  glBindTexture(GL_TEXTURE_2D, texture[2]);
  glColor4f(1, 1, 0, 0.8);
  glPushMatrix();
  glRotatef(a, 0, -1, 0);
  glBegin(GL_QUADS);
    glTexCoord2f(0, 0); glVertex3f(-100, 0, -100);
    glTexCoord2f(1, 0); glVertex3f(-100, 0, 100);
    glTexCoord2f(1, 1); glVertex3f(100, 0, 100);
    glTexCoord2f(0, 1); glVertex3f(100, 0, -100);
  glEnd();
  glPopMatrix();

  /* FPS Calculations */
  frame_counter++;
  if((frame_counter % 40) == 0)
  {
    frame_counter = 0;
    cur_time=gettime();
    sprintf(temp, "FPS: %f", 40.0/cur_time);
  }
  /* Draw FPS rate */
  glColor3f(1, 1, 1);
  glDisable(GL_TEXTURE_2D);
  glLoadIdentity();
  glTranslatef(-4.9, 4.7, -10);
  glScalef(0.0015, 0.0015, 0.002);
  draw_string(GLUT_STROKE_ROMAN, temp);
  glEnable(GL_TEXTURE_2D);
  
  glFlush();  
  glutSwapBuffers();
}

static void Key(unsigned char key, int x, int y)
{
  switch (key)
  {
    case 27: exit(0);
             break;
  }
}

void timf(int value)
{
  glutPostRedisplay();
  glutTimerFunc(16, timf, 0);
}

int main(int argc, char *argv[])
{

  WindW = 800;
  WindH = 600;
 
  printf("Fountain 3D Demo\n");
  printf("Author: Roman Podobedov\n");
  printf("Email: romka@ut.ee\n");
  printf("WWW: www.ut.ee/~romka\n");
  glutInit(&argc, argv);
  glutInitWindowSize(WindW, WindH);
  glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
  (void)glutCreateWindow("Fountain 3D Demo");
  glutFullScreen();
  Init();
  LoadTexture("particle.rgb", 0);
  LoadTexture("ground1.rgb", 1);
  LoadTexture("ground2.rgb", 2);
  glutReshapeFunc(Reshape);
  glutDisplayFunc(Draw);
  glutKeyboardFunc(Key);
  glutTimerFunc(16, timf, 0); // Set up timer for 16 ms, about 60 fps
  glutSetCursor(GLUT_CURSOR_NONE); /* Hide cursor */
  glutMainLoop();

  return 0;
}
