/* $Id: dummy.cc,v 1.1 2001/03/18 13:06:19 pesco Exp $ */
/*
 * This file contains nothing. It's just there so there's at least a single
 * source file for libGLU.la in this directory.
 */
