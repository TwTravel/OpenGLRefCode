#include <stdio.h>

int torGLUTShapesInit(void)
{
    return NULL;
}
