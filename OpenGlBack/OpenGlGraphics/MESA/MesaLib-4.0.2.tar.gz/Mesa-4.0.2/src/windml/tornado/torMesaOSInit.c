#include <stdio.h>

int torMesaOSInit(void)
{
    return NULL;
}
